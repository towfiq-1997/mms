<?php 
      session_start();
      if(!isset($_SESSION['id'])){
          header('location:index.php');
      }
      include'header.php';
      include'functions.php';
      $cur_date = date('Y-m-d');
      $conn = new mms();
      if(isset($_POST['submit'])){
          $meal = $_POST['meal']; 
          $date = $_POST['date'];
          if($date==NULL || $meal==NULL){
              $msg = "<p>Field Must Not Be Empty!</p>";
          }
          else{
            $init = $_SESSION['init'];
            $name = $_SESSION['name'];
            $sql = "INSERT INTO tbl_wishmeal(init,name,meal,meal_date) VALUES('$init','$name','$meal','$date')";
            $check = $conn->adddeposite($sql);
            if($check){
                 $msg ='<div class="success-alert"><strong>Error!</strong>
                           <p>Wished Meal Inserted Successfully</p>
                       </div>';
            }else{
               $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something Went Wrong</p>
                       </div>'; 
            }
          }
      }
?>
<div class="content">
    <div class="container-fluid">
       <div class="panel panel-default">
           <div class="panel-heading text-center">
               <h4>Add Your Desired Meal</h4>
           </div>
           <div class="panel-body">
               <div class="mms-wrapeer">
            <form action="" method="post">
               <?php if(isset($msg)){
                  echo $msg; 
                    } ?>
                <input type="text" name="date" placeholder="Enter Date" value="<?php echo $cur_date; ?>">
                <input type="number" name="meal" placeholder="Enter Meal Amount">
                <input type="submit" name="submit" value="Submit">
            </form>
        </div>
           </div>
       </div>
    </div>
</div>

<?php include'footer.php'; ?>