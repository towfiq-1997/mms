-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2018 at 12:59 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `towfiqme_mms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_meal`
--

CREATE TABLE `tbl_meal` (
  `id` int(11) NOT NULL,
  `init` varchar(50) NOT NULL,
  `meal` int(11) NOT NULL,
  `meal_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_meal`
--

INSERT INTO `tbl_meal` (`id`, `init`, `meal`, `meal_date`) VALUES
(176, 'TI', 1, '2018-12-01'),
(177, 'AM', 1, '2018-12-01'),
(178, 'SM', 1, '2018-12-01'),
(179, 'SK', 1, '2018-12-01'),
(180, 'RI', 0, '2018-12-01'),
(181, 'MTI', 1, '2018-12-01'),
(182, 'SKR', 2, '2018-12-01'),
(183, 'TI', 2, '2018-12-02'),
(184, 'AM', 2, '2018-12-02'),
(185, 'SM', 2, '2018-12-02'),
(186, 'SK', 2, '2018-12-02'),
(187, 'RI', 0, '2018-12-02'),
(188, 'MTI', 2, '2018-12-02'),
(189, 'SKR', 2, '2018-12-02'),
(190, 'TI', 2, '2018-12-03'),
(191, 'AM', 2, '2018-12-03'),
(192, 'SM', 2, '2018-12-03'),
(193, 'SK', 2, '2018-12-03'),
(194, 'RI', 0, '2018-12-03'),
(195, 'MTI', 2, '2018-12-03'),
(196, 'SKR', 2, '2018-12-03'),
(197, 'TI', 2, '2018-12-04'),
(198, 'AM', 2, '2018-12-04'),
(199, 'SM', 2, '2018-12-04'),
(200, 'SK', 1, '2018-12-04'),
(201, 'RI', 0, '2018-12-04'),
(202, 'MTI', 2, '2018-12-04'),
(203, 'SKR', 2, '2018-12-04'),
(204, 'TI', 1, '2018-12-06'),
(205, 'AM', 2, '2018-12-06'),
(206, 'SM', 2, '2018-12-06'),
(207, 'SK', 2, '2018-12-06'),
(208, 'RI', 0, '2018-12-06'),
(209, 'MTI', 2, '2018-12-06'),
(210, 'SKR', 2, '2018-12-06'),
(211, 'TI', 0, '2018-12-05'),
(212, 'AM', 0, '2018-12-05'),
(213, 'SM', 2, '2018-12-05'),
(214, 'SK', 2, '2018-12-05'),
(215, 'RI', 0, '2018-12-05'),
(216, 'MTI', 0, '2018-12-05'),
(217, 'SKR', 2, '2018-12-05'),
(218, 'TI', 2, '2018-12-07'),
(219, 'AM', 2, '2018-12-07'),
(220, 'SM', 2, '2018-12-07'),
(221, 'SK', 2, '2018-12-07'),
(222, 'RI', 0, '2018-12-07'),
(223, 'MTI', 2, '2018-12-07'),
(224, 'SKR', 2, '2018-12-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_meal`
--
ALTER TABLE `tbl_meal`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_meal`
--
ALTER TABLE `tbl_meal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
