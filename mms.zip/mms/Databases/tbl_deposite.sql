-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2018 at 12:58 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `towfiqme_mms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_deposite`
--

CREATE TABLE `tbl_deposite` (
  `id` int(11) NOT NULL,
  `init` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `d_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_deposite`
--

INSERT INTO `tbl_deposite` (`id`, `init`, `amount`, `d_date`) VALUES
(37, 'MTI', 700, '2018-12-02'),
(38, 'SM', 700, '2018-12-02'),
(39, 'SKR', 700, '2018-12-02'),
(40, 'TI', 700, '2018-12-04'),
(41, 'SK', 700, '2018-12-04'),
(42, 'AM', 700, '2018-12-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_deposite`
--
ALTER TABLE `tbl_deposite`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_deposite`
--
ALTER TABLE `tbl_deposite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
