<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';

      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
      <div class="panel panel-default">
          <div class="panel-heading text-center">
          <h4>Add Deposite</h4>
          </div>
              <div class="panel-body">
                  <div class="mms-wrapeer">
                      <?php
        
        if(isset($_POST['submit'])){
            $member = $_POST['member'];
            $dpamount = $_POST['dpamount'];
            
            if($member == NULL || $dpamount==NULL){
               $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Fields Must Not Be Empty</p>
                       </div>';
            }else{
               $date = date("Y-m-d"); 
                $sql ="INSERT INTO tbl_deposite(init,amount,d_date) VALUES('$member','$dpamount','$date')";
                $check = $conn->adddeposite($sql);
                if($check){
                     $msg ='<div class="success-alert"><strong>Error!</strong>
                           <p>Deposite Successfully</p>
                       </div>';
                }else{
                     $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>';
                }
                
                
            }
            
            
        }
         $sql = "SELECT * FROM tbl_user";
         $result = $conn->select($sql);
        
        ?>
                   <?php if(isset($msg)){
    
                         echo $msg;
    
                      } ?>
                      <form action="" method="post">
                   <label for="Dpam">Enter Amount</label>
                    <input type="number" name="dpamount" placeholder="Enter amount">
                    <label for="Select">Select Member</label>
                     <select name="member">
               <?php
                         if($result):
                   while($row = $result->fetch_assoc()): ?>
                  <option value="<?php echo $row['init']; ?>"><?php echo $row['name']; ?></option>
                  <?php endwhile;
                        endif;  
                         ?>
                   </select>
                    <input type="submit" name="submit" value="Submit">
                    </form>
                  </div>
                 </div>
          </div>
      </div>
</div>
<?php include'footer.php'; ?>