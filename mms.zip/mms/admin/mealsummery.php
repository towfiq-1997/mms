<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
        <table class="table">
            <tr>
                <th>Serial</th>
                <th>Name</th>
                <th>Deposit</th>
                <th>Net Meal</th>
                <th>Balance</th>
            </tr>
            <?php
            $sql = "SELECT * FROM tbl_user";
            $result = $conn->select($sql);
            $i =1 ;
            if($result) :
            while($row = $result->fetch_assoc()) : ?>
            <tr>
                <td>
                  <?php echo $i; ?>  
                </td>
                <td>
                  <?php echo $row['name']; ?>  
                </td>
                <td>
                   <?php
                    $init_d = $row['init'];
                    $nt_dp = $conn->summerydp($init_d);
                    echo $nt_dp;
                    
                    ?> 
                </td>
                <td>
                   <?php
                    $init_m = $row['init'];
                    $nt_m = $conn->summerym($init_m);
                    echo $nt_m;
                    
                    ?> 
                </td>
                <td>
                   <?php
                    $init_b = $row['init'];
                    $nt_m = $conn->balance($init_m);
                    echo $nt_m;
                    
                    ?> 
                </td>
            </tr>
           <?php $i++; endwhile;
            endif;
            
            ?>
        </table>
    </div>
</div>
<?php include'footer.php'; ?>