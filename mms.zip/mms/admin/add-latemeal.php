<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
      $today_date = date('Y-m-d');
?>
<div class="content input-customize">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h4>Add Daily Meal</h4>
            </div>
            <div class="panel-body">
              <?php
                if(isset($_POST['submit'])){
                    $mealcount = $_POST['mealcount'];
                    $late_date =$_POST['late_date'];
                    $insert = $conn->insertmealcount($mealcount,$late_date);
                }
                if(isset($insert)){
                   echo $insert;
                }
                
                ?>
               <form action="" method="post">
                   <label for="Latemeal">Enter missed date</label>
                   <input type="text" name="late_date" value ="<?php echo $today_date ; ?>">
                <table class="table">
                    <tr>
                        <th>Initial</th>
                        <th>Name</th>
                        <th>Meal</th>
                    </tr>
                    <?php
                    $sql="SELECT * FROM tbl_user";
                    $result = $conn->select($sql);
                    while($row=$result->fetch_assoc()):?>
                    <tr>
                        <td><?php echo $row['init']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>
                            <input class="width-customize" type="number" name="mealcount[<?php echo $row['init']; ?>]" placeholder="Add Meal Count" value ="2">
                        </td>
                    </tr>
                   <?php $i++; endwhile; ?>
                </table>
                <input type="submit" name="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>