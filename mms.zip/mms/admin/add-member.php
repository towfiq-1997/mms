<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Add member</h3>
            </div>
            <div class="panel-body">
                 <?php
        if(isset($_POST['submit'])){
            
            $init = $_POST['init'];
            $name = $_POST['name'];
            $pass = $_POST['pass'];
            if($init == NULL || $name==NULL || $pass==NULL){
              $errmsg = "<div>Field Must Not Be Empty!</div>";
            }else{
                $sql ="INSERT INTO tbl_user(init,name,pass) VALUES('$init','$name','$pass')";
                $check = $conn->adddeposite($sql);
                if($check){
                    $msg ='<div class="success-alert"><strong>Error!</strong>
                           <p>Member added successfully</p>
                       </div>';
                }else{
                    $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>'; 
                }
            }
        }
        
        if(isset($msg)){
            echo $msg;
        }
        ?>
                <div class="mms-wrapeer">
                    <form action="" method="POST">
                         <label for="init">Insert Initial</label>
                         <input type="text" name="init" placeholder="Insert a unique initial">
                         <label for="Name">Insert Full Name</label>
                         <input type="text" name="name" placeholder=" Name">
                         <label for="pass">Insert password</label>
                         <input type="text" name="pass" placeholder="Password">
                         <input type="submit" name="submit" value="Insert">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>