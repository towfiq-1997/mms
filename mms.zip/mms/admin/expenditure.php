<?php 
session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
include'header.php';
include'../functions.php';
$conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
       <div class="panel panel-default">
           <div class="panel-heading text-center">
               <h4>Expenditure List</h4>
           </div>
           <div class="panel-body">
               <table class="table">
            <tr>
                <th>Serial</th>
                <th>Id</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Member</th>
            </tr>
            <?php
            $sql="SELECT * FROM tbl_expenditure";
            $result=$conn->select($sql);
            $i=1;
                if($result) :
            while($row = $result->fetch_assoc()): ?>
               <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td><?php echo $row['amount']; ?></td>
                <td><?php echo $row['ex_person']; ?></td>
               </tr>
           <?php $i++; endwhile;
                       endif;
                   ?>
        </table> 
           </div>
       </div>
    </div>
</div>
<?php include'footer.php'; ?>