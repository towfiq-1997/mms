<?php 
session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }

include'header.php';
include'../functions.php';
$conn = new mms();
$dt = $_GET['date'];
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h4><?php echo $dt; ?></h4>
            </div>
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Init</th>
                        <th>Meal</th>
                    </tr>
                    <?php
                     $check = $conn->datebased($dt);
                    if($check) :
                    while($row = $check->fetch_assoc()) : ?>
                       <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['init']; ?></td>
                        <td><?php echo $row['meal']; ?></td>
                    </tr>
                     <?php endwhile;
                           endif;
                        ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>