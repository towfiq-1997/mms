<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
      $dt = $_GET['date'];
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h4>Update Daily Meal</h4>
            </div>
            <div class="panel-body">
              <?php
                if(isset($_POST['submit'])){
                    $mealcount = $_POST['mealcount'];
                    $check = $conn->updatemeals($mealcount,$dt);
                }
                
                if(isset($check)){
                   echo $check;
                }
                
                ?>
               <form action="" method="post">
                <table class="table">
                    <tr>
                        <th>Serial</th>
                        <th>Initial</th>
                        <th>Name</th>
                        <th>Meal</th>
                    </tr>
                    <?php
                    $sql="SELECT tbl_user.name,tbl_meal.*
                    FROM tbl_user
                    INNER JOIN tbl_meal ON tbl_user.init=tbl_meal.init 
                    WHERE meal_date='$dt'";
                    $result = $conn->select($sql);
                    $i = 1;
                    while($row=$result->fetch_assoc()):?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['init']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>
                            <input type="number" name="mealcount[<?php echo $row['init']; ?>]" placeholder="Add Meal Count" value="<?php echo $row['meal']; ?>">
                        </td>
                    </tr>
                   <?php $i++; endwhile; ?>
                </table>
                <input type="submit" name="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>