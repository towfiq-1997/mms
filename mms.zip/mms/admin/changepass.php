<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php'; 
      include'../functions.php';
      $conn = new mms();

?>
<div class="content">
    <div class="container-fluid">
      <div class="panel panel-default">
          <div class="panel-heading text-center">
              <h4>Updated Admin Password</h4>
          </div>
          <div class="panel-body">
              <div class="mms-wrapeer">
          <?php
           if(isset($_POST['submit'])){
              $pass = $_POST['pass'];
              $id = $_SESSION['admin'];
              if($pass == !NULL){
                  $sql = "UPDATE table_admin SET password ='$pass' WHERE id='$id'";
              $result = $conn->updatepass($sql);
             if($result){
                 $msg ='<div class="success-alert"><strong>Success!</strong>
                           <p>Passwsord Change Successfully</p>
                       </div>';
               }else{
                     $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Field Must Not Be Empty</p>
                       </div>';
               }
              }
              else{
                  $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>';
              }
         } 
         if(isset($msg)){
             echo $msg;
           }
           
           ?>
           <form action="" method="post">
               <input type="text" name="pass" placeholder="Insert your new password here">
               <input type="submit" name="submit" value="Submit">
           </form>
       </div> 
          </div>
      </div>
    </div>
</div>
<?php include'footer.php'; ?>