<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $date = date('Y-m-d');
      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h4><?php echo $date; ?></h4>
            </div>
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <th>Serial</th>
                        <th>Name</th>
                        <th>Init</th>
                        <th>Meal</th>
                    </tr>
                    <?php
                    $sql = "SELECT * FROM tbl_wishmeal WHERE meal_date ='$date'";
                    $resultt = $conn->select($sql);
                    $i =1 ;
                    if($resultt) :
                    while($row = $resultt->fetch_assoc()): ?>
                        <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['init']; ?></td>
                        <td><?php echo $row['meal']; ?></td>
                        </tr>
                   <?php $i++;
                         endwhile;
                         endif;
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>