<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php'; 
      include'../functions.php';
      $conn = new mms();

?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
                    <div class="col-md-4 text-center">
                        <div class="square-box">
                           <?php
                            $sql = "SELECT meal FROM tbl_meal";
                            $resultt = $conn->select($sql);
                            $netmeal = 0;
                            if($resultt){
                                while($row = $resultt->fetch_assoc()){
                                $netmeal += $row['meal'];
                             }
                            }
                            ?>
                            <h4>Net Meal</h4>
                            <p class="number-counter"><?php echo $netmeal; ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                       
                        <div class="square-box">
                             <?php
                            $sql = "SELECT amount FROM tbl_deposite";
                            $resultt = $conn->select($sql);
                            $netdp = 0;
                            if($resultt){
                                while($row = $resultt->fetch_assoc()){
                                 $netdp += $row['amount'];
                             }
                            }
                            ?>
                           <h4>Net Deposit</h4>
                           <p class="number-counter"><?php echo $netdp; ?>TK</p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="square-box">
                          <?php
                            $sql = "SELECT amount FROM tbl_expenditure";
                            $resultt = $conn->select($sql);
                            $netexp = 0;
                            if($resultt){
                             while($row = $resultt->fetch_assoc()){
                                 $netexp += $row['amount'];
                             }   
                            }
                            ?>
                           <h4>Net Expenditure</h4>
                           <p class="number-counter"><?php echo $netexp; ?>TK</p>
                        </div>
                    </div>
                     <div class="row">
                    <div class="col-md-4 text-center">
                       <?php
                            $sql = "SELECT * FROM tbl_user";
                            $resultt = $conn->select($sql);
                            $number = $resultt->num_rows;
                            ?>
                        <div class="square-box">
                            <h4>Members</h4>
                            <p class="number-counter"><?php echo $number; ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="square-box">
                           <h4>Managers Have</h4>
                           <p class="number-counter"><?php echo $conn->managershave(); ?>TK</p>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="square-box">
                           <h4>Meal Rate</h4>
                           <p class="number-counter"><?php echo $conn->mealrate(); ?>TK</p>
                        </div>
                    </div>
                </div>
                </div>
    </div>
</div>
<?php include'footer.php'; ?>