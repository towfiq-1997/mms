<?php include'../functions.php'; 
session_start();
$id =isset($_SESSION['admin'])? $_SESSION['admin']: NULL;
if($id==!NULL){
          header('location:dashboard.php?id='.$id.'');
      }

if(isset($_POST['submit'])){
   
   $conn = new mms();
   $username = $_POST['username'];
   $pass = $_POST['password'];
    
    $sql="SELECT * FROM table_admin WHERE name='$username' AND password='$pass'";
    $check = $conn->adminlogin($sql);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
         <!--     Login Registration     -->
         <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
   <div class="bg-wrapper">
       <div class="login-body">
           <form action="" method="post">
               <label for="Username"><b>Username</b></label>
               <input type="text" name="username">
               <label for="Password"><b>Password</b></label>
               <input type="password" name="password">
               <input type="submit" name="submit" value="Login">
           </form>
       </div>
   </div>
</body>
</html>