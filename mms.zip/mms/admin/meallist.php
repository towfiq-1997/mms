<?php 
session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
include'header.php';
include'../functions.php';
$conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
       <div class="panel panel-default">
           <div class="panel-heading text-center">
               <h4>Meal View</h4>
           </div>
           <div class="panel-body">
               <table class="table">
            <tr>
                <th>Serial</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
            <?php
            $sql="SELECT DISTINCT meal_date FROM tbl_meal";
            $result=$conn->select($sql);
            $i=1;
            if($result):
            while($row = $result->fetch_assoc()): ?>
               <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['meal_date']; ?></td>
                <td>
                    <a class="button-style" href="single-meallist.php?date=<?php echo $row['meal_date']; ?>">View</a>
                    <a class="button-style" href="updatemeals.php?date=<?php echo $row['meal_date']; ?>">Edit</a>
                </td>
               </tr>
           <?php $i++; endwhile;
              endif;     
            ?>
        </table> 
           </div>
       </div>
    </div>
</div>
<?php include'footer.php'; ?>