<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
?>
<div class="content input-customize">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h4>Add Daily Meal</h4>
            </div>
            <div class="panel-body">
              <?php
                if(isset($_POST['submit'])){
                    $mealcount = $_POST['mealcount'];
                    $cur_date = date('Y-m-d');
                    $insert = $conn->insertmealcount($mealcount,$cur_date);
                }
                if(isset($insert)){
                   echo $insert;
                }
                
                ?>
               <form action="" method="post">
                <table class="table">
                    <tr>
                        <th>Initial</th>
                        <th>Name</th>
                        <th>Meal</th>
                    </tr>
                    <?php
                    $sql="SELECT * FROM tbl_user";
                    $result = $conn->select($sql);
                    while($row=$result->fetch_assoc()):?>
                    <tr>
                        <td><?php echo $row['init']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td>
                            <input class="width-customize"  type="number" name="mealcount[<?php echo $row['init']; ?>]" placeholder="Add Meal Count" value ="2">
                        </td>
                    </tr>
                   <?php $i++; endwhile; ?>
                </table>
                <input type="submit" name="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>