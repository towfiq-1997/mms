<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h3>Members List</h3> 
            </div>
            <div class="panel-body">
                 <table class="table">
            <tr>
                <th>Serial</th>
                <th>Init</th>
                <th>Name</th>
                <th>Action</th>
            </tr>
            <?php
            $sql = "SELECT id,init,name FROM tbl_user";
            $result = $conn->select($sql);
            $i =1 ;
            if($result) :
            while($row = $result->fetch_assoc()) : ?>
            <tr>
                <td>
                  <?php echo $i; ?>  
                </td>
                <td>
                   <?php
                     echo $row['init'];
                    ?> 
                </td>
                <td>
                  <?php echo $row['name']; ?>  
                </td>
                <td>
                  <a href="delete-member.php?id=<?php echo $row['init']; ?>">Delete</a>  
                </td>
            </tr>
           <?php $i++; endwhile;
            endif;
            
            ?>
        </table>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>