<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
      $date = date('Y-m-d');

?>
<div class="content">
    <div class="container-fluid">
      <div class="panel panel-default">
          <div class="panel-heading text-center">
              <h4>Add Expenditure</h4>
          </div>
          <div class="panel-body">
              <div class="mms-wrapeer">
                 <?php
        if(isset($_POST['submit'])){
            
            $mdate = $_POST['mdate'];
            $exppp = $_POST['exppp'];
            $member = $_POST['member'];
            if($mdate == NULL || $exppp==NULL){
              $errmsg = "<div>Field Must Not Be Empty!</div>";
            }else{
                $sql ="INSERT INTO tbl_expenditure(date,amount,ex_person) VALUES('$mdate','$exppp','$member')";
                $check = $conn->adddeposite($sql);
                if($check){
                    $msg ='<div class="success-alert"><strong>Success!</strong>
                           <p>Expenditure Added Successfully</p>
                       </div>';
                }else{
                    $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>'; 
                }
            }
        }
        
        if(isset($msg)){
            echo $msg;
        }
         $sql = "SELECT * FROM tbl_user";
         $result = $conn->select($sql);
        ?>
        <form action="" method="post">
            <label for="Mdate">Date of expenditure</label>
            <input type="text" name="mdate" value="<?php echo $date; ?>">
            <label for="Amount">Amount of expenditure</label>
            <input type="number" name="exppp" placeholder="Enter amount">
            <label for="Whodid">Select who did</label>
            <select name="member">
               <?php
                         if($result):
                   while($row = $result->fetch_assoc()): ?>
                  <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
                  <?php endwhile;
                        endif;  
                         ?>
                   </select>
            <input type="submit" name="submit" value="Submit">
        </form> 
              </div>
       </div>
      </div>
    </div>
</div>

<?php include'footer.php'; ?>