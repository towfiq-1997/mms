<?php 
session_start();
include'functions.php';
$id =isset($_SESSION['id'])? $_SESSION['id']: NULL;
$init = isset($_SESSION['init'])?$_SESSION['init']:NULL;
if($id==!NULL && $init==!NULL){
          header('location:dashboard.php?id='.$id.'&init='.$init.'');
      }

if(isset($_POST['submit'])){
   
   $conn = new mms();
   $username = $_POST['username'];
   $pass = $_POST['password'];
    
    $sql="SELECT * FROM tbl_user WHERE init='$username' AND pass='$pass'";
    $check = $conn->login($sql);
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
         <!--     Login Registration     -->
         <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
   <div class="bg-wrapper">
       <div class="login-body">
           <form action="" method="post">
               <label for="Username"><b>Username</b></label>
               <input type="text" name="username">
               <label for="Password"><b>Password</b></label>
               <input type="password" name="password">
               <input type="submit" name="submit" value="Login">
           </form>
       </div>
   </div>
</body>
</html>