<?php 
      session_start();
      if(!isset($_SESSION['id'])){
          header('location:index.php');
      }
      include'header.php'; 
      include'functions.php';
      $conn = new mms();

?>
<div class="content">
    <div class="container-fluid">
      <div class="panel panel-default">
          <div class="panel-heading text-center">
              <h4>Update User Password</h4>
          </div>
          <div class="panel-body">
              <div class="mms-wrapeer">
          <?php
           if(isset($_POST['submit'])){
              $pass = $_POST['pass'];
              $init = $_SESSION['init'];
              if($pass == !NULL){
                $sql = "UPDATE tbl_user SET pass ='$pass' WHERE init='$init'";
              $result = $conn->updatepass($sql);
             if($result){
                 $msg ='<div class="success-alert"><strong>Success!</strong>
                           <p>Passwsord Change Successfully</p>
                       </div>';
             }else{
               $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>';
            }
           }
         } 
         if(isset($msg)){
             echo $msg;
           }
           
           ?>
           <form action="" method="post">
               <input type="text" name="pass" placeholder="Enter your new password">
               <input type="submit" name="submit" value="Submit">
           </form>
       </div> 
          </div>
      </div>
    </div>
</div>
<?php include'footer.php'; ?>