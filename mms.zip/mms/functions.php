<?php 
define('DBHOST','localhost');
define('DBUSER','towfiqme_towfiq');
define('DBPASS','@asdfg12345');
define('DBNAME','towfiqme_mms');

class mms{
   public $host   = DBHOST; 
   public $user   = DBUSER; 
   public $pass   = DBPASS; 
   public $dbname = DBNAME; 
    
    public $link;
    
    public function __construct(){
        $this->connectdb();
    }
    public function connectdb(){
        $this->link = new mysqli($this->host,$this->user,$this->pass,$this->dbname);
        if(!$this->link){
            return false;
        }
        
    }
    public function login($sql){
        $result =$this->link->query($sql);
        if($result->num_rows>0){
            $row = $result->fetch_assoc();
            $_SESSION['id'] = $row['id'];
            $_SESSION['init'] = $row['init'];
            $_SESSION['name'] = $row['name'];
            $id = $row['id'];
            $init = $row['init'];
            header('location:dashboard.php?id='.$id.'&init='.$init.'');
            
        }else{
         $msg = "<p>Password Or Email Doesn't Match Try Again!</p>";
            return $msg;
        }
    }
    public function adminlogin($sql){
        $result =$this->link->query($sql);
        if($result->num_rows>0){
            $row = $result->fetch_assoc();
            $_SESSION['admin'] = $row['id'];
            $id = $_SESSION['admin'];
            header('location:dashboard.php?id='.$id.'');
            
        }else{
         $msg = "<p>Password Or Email Doesn't Match Try Again!</p>";
            return $msg;
        } 
    }
    
   public function select($sql){
      $query = $this->link->query($sql);
       if($query->num_rows>0){
           return $query;
       }else{
           return false;
       }
        
    }
   public function balance($id){
       $sql = "SELECT amount FROM tbl_expenditure";
       $sql2 = "SELECT meal FROM tbl_meal";
       $sql3 = "SELECT meal FROM tbl_meal WHERE init='$id'";
       $sql4 = "SELECT amount FROM tbl_deposite WHERE init='$id'";
       $query = $this->link->query($sql);
       $query2 = $this->link->query($sql2);
       $query3 = $this->link->query($sql3);
       $query4 = $this->link->query($sql4);
       
       $netexpp = 0;
       if($query){
          while($row = $query->fetch_assoc()){
           $netexpp += $row['amount'];
       } 
       }
       $netmealll = 0;
       
       if($query2){
           while($row = $query2->fetch_assoc()){
           $netmealll += $row['meal'];
        }
       }
       $pmeal = 0;
       if($query3){
           while($row = $query3->fetch_assoc()){
           $pmeal += $row['meal'];
        }
       }
       $pedep = 0;
       if($query4){
           while($row = $query4->fetch_assoc()){
           $pedep += $row['amount'];
        }
       }
       
       $mealrate =$netexpp/$netmealll;
       $pbal = $mealrate*$pmeal;
       $mainbal = $pedep-$pbal;
       return $mainbal; 
          
   }
  
   public function mealrate(){
     $sql = "SELECT amount FROM tbl_expenditure";  
     $sql2 = "SELECT meal FROM tbl_meal";
     $query = $this->link->query($sql);
     $query2 = $this->link->query($sql2);
     $netexpp = 0;
     if($query){
         while($row = $query->fetch_assoc()){
           $netexpp += $row['amount'];
       }
     }
     $netmealll = 0;
       if($query2){
         while($row = $query2->fetch_assoc()){
           $netmealll += $row['meal'];
       }
       }
    $mealrate =$netexpp/$netmealll;
    return $mealrate;
     
   }
  public function managershave(){
     $sql = "SELECT amount FROM tbl_deposite";  
     $sql2 = "SELECT amount FROM tbl_expenditure";
     $query = $this->link->query($sql);
     $query2 = $this->link->query($sql2);
     $netdpp = 0;
      if($query){
         while($row = $query->fetch_assoc()){
           $netdpp += $row['amount'];
       } 
      }
     $netexpp = 0;
      if($query2){
          while($row = $query2->fetch_assoc()){
           $netexpp += $row['amount'];
       }
      }
    $mhave =$netdpp-$netexpp;
    return $mhave;
      
  }
 
 public function adddeposite($sql){
     
     $result = $this->link->query($sql);
     if($result){
         return $result; 
     }
     else{
         return false;
     }
 }
 
 public function insertmealcount($mealcount,$cur_date){
     $query = "SELECT DISTINCT meal_date FROM tbl_meal;";
     $result = $this->link->query($query);
     if($result){
        while($row = $result->fetch_assoc()){
        if($cur_date==$row['meal_date']){
             $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Meal Already Inputed</p>
                       </div>';
            return $msg;
        }
       } 
     }
     foreach($mealcount as $pinit => $pmeal){
         $insquery = "INSERT INTO tbl_meal (init,meal,meal_date) VALUES('$pinit','$pmeal','$cur_date')";
         $data_ins = $this->link->query($insquery);
     }
     if($insquery){
         $msg ='<div class="success-alert"><strong>Success!</strong>
                           <p>Meal Inserted Succesfully</p>
                       </div>';
        return $msg;
      }else{
         $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>';
        return $msg;  
      }
     
   }
    public function datebased($dt){
    $sqlc="SELECT tbl_user.name,tbl_meal.*
    FROM tbl_user
    INNER JOIN tbl_meal ON tbl_user.init=tbl_meal.init 
    WHERE meal_date='$dt'";
    $resultl = $this->link->query($sqlc);
    return $resultl;
 }
    
    public function summerydp($init_d){
      $sql = "SELECT amount FROM tbl_deposite WHERE init = '$init_d'";
      $resultt = $this->link->query($sql);
      $udp = 0;
        if($resultt){
           while($row = $resultt->fetch_assoc()){
             $udp += $row['amount'];
          } 
        }
    return $udp;
   } 
    
    public function summerym($init_m){
        
        $sql = "SELECT meal FROM tbl_meal WHERE init = '$init_m'";
        $resultt = $this->link->query($sql);
        $umeal = 0;
        if($resultt){
           while($row = $resultt->fetch_assoc()){
           $umeal += $row['meal'];
            
           } 
        }
        return $umeal; 
    }
    
    
    public function updatemeals($mealcount,$dt){
        foreach($mealcount as $pinit => $pmeal){
         $updatequery = "UPDATE tbl_meal SET meal='$pmeal' WHERE init='$pinit' AND meal_date='$dt'";
         $data_up = $this->link->query($updatequery);
     }
        if($updatequery){
         $msg ='<div class="success-alert"><strong>Success</strong>
                           <p>Update Meal Successfull</p>
                       </div>';
        return $msg;
      }
        else{
         $msg ='<div class="error-alert"><strong>Error!</strong>
                           <p>Something went wrong</p>
                       </div>';
        return $msg;  
      }
    }
    
    public function updatepass($sql){
        $query = $this->link->query($sql);
        if($query){
           return $query;  
        }
        else{
           return false; 
        }
    }
  
}



?>