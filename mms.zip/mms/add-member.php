<?php 
      session_start();
      if(!isset($_SESSION['admin'])){
          header('location:index.php');
      }
      include'header.php';
      include'../functions.php';
      $conn = new mms();
?>
<div class="content">
    <div class="container-fluid">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Add memeber</h3>
            </div>
            <div class="panel-body">
                <div class="mms-wrapeer">
                    <form action="" method="post">
                         <label for="init">Insert Initial</label>
                         <input type="text" name="init" placeholder="Insert a unique initial">
                         <label for="Name">Insert Full Name</label>
                         <input type="text" name="name" placeholder=" Name">
                         <label for="pass">Insert password</label>
                         <input type="text" name="pass" placeholder="Password">
                         <input type="submit" name="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include'footer.php'; ?>